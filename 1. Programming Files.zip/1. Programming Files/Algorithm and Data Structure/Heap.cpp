#include<iostream>
#include<algorithm>
#include<stdio.h>
#include<string.h>
#include<math.h>
using namespace std;

int max heapify(A,i){

}

int Parent(i){
    return i/2;
}

int left(i){
    return 2i;
}

int right(i){
    return 2i+1;

}


int main()
{
    long long int b,c,d,e,f=0,g,h,i,j,k=0,l,m,n,x,y,max=0;


    int A[11]={16,4,10,14,7,9,3,2,8,1};


    return 0;
}



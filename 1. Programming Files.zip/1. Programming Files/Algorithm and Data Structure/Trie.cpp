#include<bits/stdc++.h>
using namespace std;
#define ll long long int

long long int mod = 1e9 + 7;

struct node {
    int endmark;
    node *next[26 + 1];
    node()
    {
        endmark = 0;
        for(int i = 0; i < 26; i++)
            next[i] = NULL;
    }
} *root;

void insert(string str)
{
    node* curr = root;
    for(int i = 0; i < str.size(); i++) {
        int id = str[i] - 'a';
        if(curr->next[id] == NULL)
            curr->next[id] = new node();
        curr = curr->next[id];
    }
    curr->endmark++;
}

void delet(string str) {
  node* curr = root;
    for(int i = 0; i < str.size(); i++) {
        int id = str[i] - 'a';
        if(curr->next[id] == NULL)
            curr->next[id] = new node();
        curr = curr->next[id];
    }
    curr->endmark--;
}

int search(string str)
{
    node* curr = root;
    for(int i = 0; i < str.size(); i++) {
        int id = str[i] - 'a';
        if(curr->next[id] == NULL)
            return 0;
        curr = curr->next[id];
    }
    return curr->endmark;
}

void del(node* curr)
{
    for(int i = 0; i < 26; i++)
        if(curr->next[i])
            del(curr->next[i]);
    delete (curr);
}



struct node1 {
    int endmark;
    node1 *next[26 + 1];
    node1()
    {
        endmark = 0;
        for(int i = 0; i < 26; i++)
            next[i] = NULL;
    }
} *root1;

void insert1(string str)
{
    node1* curr = root1;
    for(int i = 0; i < str.size(); i++) {
        int id = str[i] - 'a';
        if(curr->next[id] == NULL)
            curr->next[id] = new node1();
        curr = curr->next[id];
    }
    curr->endmark++;
}

void delete1(string str) {
  node1* curr = root1;
    for(int i = 0; i < str.size(); i++) {
        int id = str[i] - 'a';
        if(curr->next[id] == NULL)
            curr->next[id] = new node1();
        curr = curr->next[id];
    }
    curr->endmark--;
}

int search1(string str)
{
    node1* curr = root1;
    for(int i = 0; i < str.size(); i++) {
        int id = str[i] - 'a';
        if(curr->next[id] == NULL)
            return 0;
        curr = curr->next[id];
    }
    return curr->endmark;
}

void del1(node1* curr)
{
    for(int i = 0; i < 26; i++)
        if(curr->next[i])
            del1(curr->next[i]);
    delete (curr);
}



int main()
{
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  int t;
  cin >> t;
  while(t--) {
    int n, m;
    cin >> n >> m;
    vector <string> vs1, vs2;
    root = new node();
    for(int i = 0; i < n; i++) {
      string st;
      cin >> st;
      vs1.push_back(st);
      insert(st);
    }

    ll ans1 = 0, ans2 = 0;
    for(int i = 0; i < m; i++) {
      string st;
      cin >> st;
      vs2.push_back(st);
      int v = search(st);
      if(v){
        ans1 += v;
        ans1 %= mod;
      }
    }

    root1 = new node1();
    for(int i = 0; i < m; i++) {
      insert1(vs2[i]);
    }
    for(int i = 0; i < n; i++) {
      int v = search1(vs1[i]);
      if(v) {
        ans2 += v;
        ans2 %= mod;
      }
    }

    int q;
    cin >> q;
    while(q--) {
      int a, b, c;
      cin >> a >> b >> c;
      char ch;
      cin >> ch;

      if(a == 2) {
        int v = search(vs2[b - 1]);
        ans1 -= v;
        ans1 = (ans1 + mod) % mod;
        delete1(vs2[b - 1]);
        vs2[b - 1][c - 1] = ch;
        int v1 = search(vs2[b - 1]);
        ans1 += v1;
        ans1 %= mod;

        cout << ans1 << endl;
      }
      else {
        int v = search1(vs1[b - 1]);
        ans2 -= v;
        ans2 = (ans2 + mod) % mod;
        delet(vs1[b - 1]);
        vs1[b - 1][c - 1] = ch;
        int v1 = search1(vs1[b - 1]);
        ans2 += v1;
        ans2 %= mod;

        cout << ans2 << endl;
      }
    }

    del(root);
    del1(root1);
  }

  return 0;
}

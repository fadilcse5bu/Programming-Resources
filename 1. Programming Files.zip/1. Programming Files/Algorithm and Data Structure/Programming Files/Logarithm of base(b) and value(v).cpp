#include<bits/stdc++.h>
using namespace std;

double logarithm(double b, double v){
    double x = log(v) / log(b);
    return x;
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    //Enter base
    double b;
    cin >> b;
    //Enter value
    double v;
    cin >> v;

    // Final Value of Log_b(v)
    cout << logarithm(b, v);
}


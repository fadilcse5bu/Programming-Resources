// Given the numbers a and b, calculate the digit sum of [a,b].

#include <bits/stdc++.h>
using namespace std;
#define ll unsigned long long int

ll dp[20][180][2][2], k;
int len = 20;
string a, b; // fa = flag of lower number(a), fb = flag of upper number(b)

ll cal(int pos, int sum, bool fa, bool fb) {
  if(pos == len) return sum;
  ll &ret = dp[pos][sum][fa][fb];
  if(ret != -1) return ret;
  ret = 0;
  int low = fa? 0:a[pos]-'0';
  int high = fb? 9:b[pos]-'0';
  for(int i = low; i <= high; i++) {
    ret = (ret + cal(pos+1, sum + i, fa|(i>low), fb|(i<high)));
  }
  return ret;
}

void process() {
  memset(dp, -1, sizeof dp);
  int la = a.size(), lb = b.size();
  string sa = "", sb = "";
  for(int i = la; i < len; i++) sa += '0';
  for(int i = lb; i < len; i++) sb += '0';
  a = sa + a;
  b = sb + b;
}

int main()
{
  int t=1, cs=1; cin >> t;
  //memset(dp, -1, sizeof dp);
  while(t--) {
    cin >> a >> b;
    process();
    ll ans = cal(0,0,0,0);
    cout << ans << endl;
  }

  return 0;
}
/*
3
0 10
28 31
1234 56789

46
28
1128600
*/






/// How many number of integers in the range [A, B] which are divisible by K and the sum of its digits is also divisible by K.

#include <bits/stdc++.h>
using namespace std;
#define ll long long int

ll dp[10][2][85][85], len, k;

vector <ll> dig;
void convertDigit(ll n) {
  dig.clear();
  while(n > 0) {
    dig.push_back(n%10);
    n /= 10;
  }
  reverse(dig.begin(), dig.end());
  len = dig.size();
}

ll cal(ll pos, bool tp, ll mod1, ll mod2) {
  if(pos == len) {
    if(mod1 == 0 && mod2 == 0) return 1;
    return 0;
  }
  if(dp[pos][tp][mod1][mod2] != -1) return dp[pos][tp][mod1][mod2];
  ll lim;
  if(tp == 1) lim = 9;
  else lim = dig[pos];

  ll res = 0;
  for(ll i = 0; i <= lim; i++) {
    res += cal(pos+1, tp|(i < lim ? 1:0), (mod1*10+i)%k, (mod2+i)%k);
  }
  return dp[pos][tp][mod1][mod2] = res;
}

int main()
{
  int t=1, cs=1; cin >> t;
  while(t--) {
    ll a, b; cin >> a >> b >> k;
    cout << "Case " << cs++ << ": ";
    if(k > 81) {
      cout << 0 << endl;
      continue;
    }
    memset(dp, -1, sizeof dp);
    convertDigit(b);
    int ans = cal(0,0,0,0);
    memset(dp, -1, sizeof dp);
    convertDigit(a-1);
    ans -= cal(0,0,0,0);
    cout << ans << endl;
  }

  return 0;
}
/*
3
1 20 1
1 20 2
1 1000 4

Case 1: 20
Case 2: 5
Case 3: 64
*/





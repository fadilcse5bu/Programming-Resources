#include<bits/stdc++.h>
using namespace std;
#define ll long long int

struct node {
  ll endmark;
  node *next[26 + 1];
  node() {
    endmark = 0;
    for(int i = 0; i < 26; i++) next[i] = NULL;
  }
} *root;

void insert(string str) {
  node* curr = root;
  for(int i = 0; i < str.size(); i++) {
    int id = str[i] - 'a';
    if(curr->next[id] == NULL)
        curr->next[id] = new node();
    curr = curr->next[id];
  }
  curr->endmark++;
}

void delet(string str) {
  node* curr = root;
  for(int i = 0; i < str.size(); i++) {
    int id = str[i] - 'a';
    if(curr->next[id] == NULL)
        curr->next[id] = new node();
    curr = curr->next[id];
  }
  curr->endmark--;
}

int search(string str) {
  node* curr = root;
  for(int i = 0; i < str.size(); i++) {
    int id = str[i] - 'a';
    if(curr->next[id] == NULL) return 0;
    curr = curr->next[id];
  }
  return curr->endmark;
}

void del(node* curr) {
  for(int i = 0; i < 26; i++)
    if(curr->next[i])
        del(curr->next[i]);
  delete (curr);
}

int main()
{
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  int t;
  cin >> t;
  while(t--) {
    int n, m;
    cin >> n >> m;
    vector <string> vs1, vs2;
    root = new node();
    for(int i = 0; i < n; i++) {
      string st;
      cin >> st;
      vs1.push_back(st);
      insert(st);
    }
    del(root);
  }

  return 0;
}


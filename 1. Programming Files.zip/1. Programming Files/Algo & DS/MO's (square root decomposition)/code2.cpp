/// calculate sum += freq(x)*freq(x)*x; where x is in ar[l,r]

#include<bits/stdc++.h>
using namespace std;
#define ll long long

const int N = 200005;
const int k = sqrt(N);
ll ans[N], sum = 0, ar[N], cnt[5*N];

struct query{
  int l, r, id;
} q[N];

bool cmp(query &a, query &b) {
  int block_a = a.l/k, block_b = b.l/k;
  if(block_a == block_b) return a.r < b.r;
  return block_a < block_b;
}

void add(int i) {
  sum -= cnt[ar[i]]*cnt[ar[i]]*ar[i];
  ++cnt[ar[i]];
  sum += cnt[ar[i]]*cnt[ar[i]]*ar[i];
}

void remove(int i) {
  sum -= cnt[ar[i]]*cnt[ar[i]]*ar[i];
  --cnt[ar[i]];
  sum += cnt[ar[i]]*cnt[ar[i]]*ar[i];
}

int main()
{
  ios::sync_with_stdio(false); cin.tie(0);

  int n, Q; cin >> n >> Q;
  for(int i = 1; i <= n; i++) cin >> ar[i];
  for(int i = 0; i < Q; i++) {
    cin >> q[i].l >> q[i].r;
    q[i].id = i;
  }
  sort(q, q+Q, cmp);

  int l = 1, r = 0;
  for(int i = 0; i < Q; i++) {
    while(l > q[i].l) add(--l);
    while(r < q[i].r) add(++r);
    while(l < q[i].l) remove(l++);
    while(r > q[i].r) remove(r--);
    ans[q[i].id] = sum;
  }
  for(int i = 0; i < Q; i++) {
    cout << ans[i] << "\n";
  }

  return 0;
}

/*
3 2
1 2 1
1 2
1 3
*/

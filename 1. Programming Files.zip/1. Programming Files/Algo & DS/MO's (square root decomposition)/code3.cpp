/// Number of inversions in ar[l,r]

#include<bits/stdc++.h>
using namespace std;
#define ll long long

const int N = 100005;
const int k = sqrt(N);
ll ans[N], ar[N], sum = 0, tree[N];

struct query{
  int l, r, id;
} q[N];

bool cmp(query &a, query &b) {
  int block_a = a.l/k, block_b = b.l/k;
  if(block_a == block_b) return a.r < b.r;
  return block_a < block_b;
}

void update(int id, int val, int n) {
  while(id <= n) {
    tree[id] += val;
    id += (id & -id);
  }
}

int query(int id) {
  int res = 0;
  while(id > 0) {
    res += tree[id];
    id -= (id & -id);
  }
  return res;
}

void add_left(int i, int n) {
  int v = query(i-1);
  sum += v;
  update(i, 1, n);
}

void add_right(int i, int n) {
  int v = query(n) - query(i);
  sum += v;
  update(i, 1, n);
}

void remove_left(int i, int n) {
  update(i, -1, n);
  int v = query(i-1);
  sum -= v;
}

void remove_right(int i, int n) {
  update(i, -1, n);
  int v = query(n) - query(i);
  sum -= v;
}

int main()
{
  ios::sync_with_stdio(false); cin.tie(0);

  int n, Q; cin >> n >> Q;
  vector <pair<int, int>> vp;
  for(int i = 1; i <= n; i++) {
    cin >> ar[i];
    vp.push_back({ar[i], i});
  }
  sort(vp.begin(), vp.end());
  int ct = 1;
  ar[vp[0].second] = 1;
  for(int i = 1; i < n; i++) {
    if(vp[i].first != vp[i-1].first) ++ct;
    ar[vp[i].second] = ct;
  }

  for(int i =0; i < Q; i++) {
    cin >> q[i].l >> q[i].r;
    q[i].id = i;
  }
  sort(q, q+Q, cmp);

  int l = 1, r = 0;
  for(int i = 0; i < Q; i++) {
    while(l > q[i].l) add_left(ar[--l], ct);
    while(r < q[i].r) add_right(ar[++r], ct);
    while(l < q[i].l) remove_left(ar[l++], ct);
    while(r > q[i].r) remove_right(ar[r--], ct);
    ans[q[i].id] = sum;
  }
  for(int i = 0; i < Q; i++) {
    cout << ans[i] << "\n";
  }

  return 0;
}
/*
5 3
1 4 2 3 1
1 2
3 5
1 5

5 5
5 4 3 2 1
1 5
1 3
1 1
1 5
2 5
*/



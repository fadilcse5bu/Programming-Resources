/// how many numbers x exist, such that number x occurs exactly x times among numbers ar[l,r]

#include<bits/stdc++.h>
using namespace std;
#define ll long long

const int N = 100005;
const int k = sqrt(N);
int ans[N], ar[N], sum = 0;
unordered_map <int, int> cnt;

struct query{
  int l, r, id;
} q[N];

bool cmp(query &a, query &b) {
  int block_a = a.l/k, block_b = b.l/k;
  if(block_a == block_b) return a.r < b.r;
  return block_a < block_b;
}

void add(int i) {
  if(cnt[ar[i]] == ar[i]) --sum;
  ++cnt[ar[i]];
  if(cnt[ar[i]] == ar[i]) ++sum;
}

void remove(int i) {
  if(cnt[ar[i]] == ar[i]) --sum;
  --cnt[ar[i]];
  if(cnt[ar[i]] == ar[i]) ++sum;
}

int main()
{
  ios::sync_with_stdio(false); cin.tie(0);

  int n, Q; cin >> n >> Q;
  for(int i = 1; i <= n; i++) cin >> ar[i];
  for(int i =0; i < Q; i++) {
    cin >> q[i].l >> q[i].r;
    q[i].id = i;
  }
  sort(q, q+Q, cmp);

  int l = 1, r = 0;
  for(int i = 0; i < Q; i++) {
    while(l > q[i].l) add(--l);
    while(r < q[i].r) add(++r);
    while(l < q[i].l) remove(l++);
    while(r > q[i].r) remove(r--);
    ans[q[i].id] = sum;
  }
  for(int i = 0; i < Q; i++) {
    cout << ans[i] << "\n";
  }

  return 0;
}
/*
7 2
3 1 2 2 3 3 7
1 7
3 4
*/



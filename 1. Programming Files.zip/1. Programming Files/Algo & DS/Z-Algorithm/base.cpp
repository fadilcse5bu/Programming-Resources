#include<iostream>
using namespace std;
#define ll long long

int const N = 1000005;
int Z[N];

void getZarr(string str) {
  int n = str.length();
  int L, R, k;
  L = R = 0;
  for(int i = 1; i < n; ++i) {
    if(i > R) {
      L = R = i;
      while (R<n && str[R-L] == str[R]) R++;
      Z[i] = R-L;
      R--;
    }
    else {
      k = i-L;
      if (Z[k] < R-i+1) Z[i] = Z[k];
      else {
        L = i;
        while (R<n && str[R-L] == str[R]) R++;
        Z[i] = R-L;
        R--;
      }
    }
  }
}

void search(string text, string pattern) {
  string concat = pattern + "$" + text;
  int L = concat.length();
  getZarr(concat);
  for (int i = 0; i < L; ++i) {
    if (Z[i] == pattern.length())
          cout << "Pattern found at index "
              << i - pattern.length() -1 << endl;
  }
}

int main()
{
    string text = "GEEKS FOR GEEKS";
    string pattern = "GEEK";
    search(text, pattern);
    return 0;
}


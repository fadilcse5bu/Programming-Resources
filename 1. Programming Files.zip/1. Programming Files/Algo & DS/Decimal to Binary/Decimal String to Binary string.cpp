#include<bits/stdc++.h>
using namespace std;

string binary;

string longDivision(string number, int divisor) {
  int len = number.size()-1;
  int dig = number[len] - '0';
  if(dig % 2 == 0) binary.push_back('0');
  else binary.push_back('1');
  string ans;
  int idx = 0;
  int temp = number[idx] - '0';
  while (temp < divisor)
      temp = temp * 10 + (number[++idx] - '0');

  while (number.size() > idx) {
    ans += (temp / divisor) + '0';
    temp = (temp % divisor) * 10 + number[++idx] - '0';
  }
  if (ans.length() == 0) return "0";

  return ans;
}

int main() {
  string n; cin >> n;
  int divisor = 2;
  while(1){
    n = longDivision(n, divisor);
    if(n == "0") break;
  }
  reverse(binary.begin(), binary.end());
  cout << binary << endl;

  return 0;
}

#include <bits/stdc++.h>
using namespace std;
#define ll long long int
const int MAXM = 1.5e7 + 5;

int spf[MAXM]; // smallest prime factor
bool notPrime[MAXM];
vector <int> prime;

void getSmallestPrimeFactor() {
  for(int i = 2; i < MAXM; i++) {
    if(!notPrime[i]) {
      prime.push_back(i);
      spf[i] = i;
    }
    for(int j = 0; j < prime.size() && 1LL * i * prime[j] < MAXM; j++) {
      notPrime[i*prime[j]] = 1;
      spf[i*prime[j]] = prime[j];
      if(i%prime[j] == 0) break;
    }
  }
}

int main()
{
  getSmallestPrimeFactor();
  for(int i = 1; i <= 50; i++) cout << i << ' ' << spf[i] << endl;

  return 0;
}



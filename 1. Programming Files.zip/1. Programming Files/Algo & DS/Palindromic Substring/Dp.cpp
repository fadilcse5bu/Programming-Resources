#include <bits/stdc++.h>
using namespace std;

int const N = 3005;
bool P[N][N];
string str;
int n;
void palindromicSubstring()
{
  for (int i = 0; i < n; i++) P[i][i] = true;
  for (int gap = 2; gap <=n; gap++) {
    for (int i = 0; i <= n-gap; i++) {
      int j = gap + i-1;
      if(i==j-1){
        P[i][j]=(str[i]==str[j]);
      }
      else {
        P[i][j]=(str[i]==str[j] && P[i+1][j-1]);
      }
    }
  }
}

int main()
{
  cin >> n >> str;
  palindromicSubstring();
  for(int i = 0; i < n; i++) {
    for(int j = i; j < n; j++) {
      cout << i << ' ' << j << ' ';
      if(P[i][j] == 0) cout << "NO" << endl;
      else cout << "YES" << endl;
    }
  }

  return 0;
}

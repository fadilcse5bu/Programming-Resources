#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

ll gcd(ll a, ll b, ll& x, ll& y) {
  if (b == 0) {
    x = 1;
    y = 0;
    return a;
  }
  ll x1, y1;
  ll d = gcd(b, a % b, x1, y1);
  x = y1;
  y = x1 - y1 * (a / b);
  return d;
}

bool find_any_solution(ll a, ll b, ll c, ll &x0, ll &y0, ll &g){
  g=gcd(abs(a), abs(b), x0, y0);
  if(c%g) return false;
  x0 *=c/g;
  y0 *=c/g;
  if(a<0) x0=-x0;
  if(b<0) y0=-y0;
  return true;
}

void shift_solution(ll & x, ll & y, ll a, ll b, ll cnt) {
  x += cnt * b;
  y -= cnt * a;
}

ll find_all_solutions(ll a, ll b, ll c, ll minx, ll maxx, ll miny, ll maxy, ll & lx, ll & rx) {
  ll x, y, g;
  if (!find_any_solution(a, b, c, x, y, g)) return 0;
  a /= g; b /= g;
  ll sign_a = a > 0 ? +1 : -1;
  ll sign_b = b > 0 ? +1 : -1;
  shift_solution(x, y, a, b, (minx - x) / b);
  if (x < minx) shift_solution(x, y, a, b, sign_b);
  if (x > maxx) return 0;
  ll lx1 = x;
  shift_solution(x, y, a, b, (maxx - x) / b);
  if (x > maxx) shift_solution(x, y, a, b, -sign_b);
  ll rx1 = x;
  shift_solution(x, y, a, b, -(miny - y) / a);
  if (y < miny) shift_solution(x, y, a, b, -sign_a);
  if (y > maxy) return 0;
  ll lx2 = x;
  shift_solution(x, y, a, b, -(maxy - y) / a);
  if (y > maxy) shift_solution(x, y, a, b, sign_a);
  ll rx2 = x;
  if (lx2 > rx2) swap(lx2, rx2);
  lx = max(lx1, lx2);
  rx = min(rx1, rx2);
  //cout << lx << ' ' << rx << endl;
  if (lx > rx) return 0;
  return (rx - lx) / abs(b) + 1;
}

ll find_maximum(ll a, ll b, ll c, ll & lx, ll & rx) {
  ll x1 = lx;
  ll y1 = (c-a*x1)/b;
  ll x2 = rx;
  ll y2 = (c-a*x2)/b;
  ll mx = min(x1+y1, x2+y2);
  return mx;
}

/// ax + by = c
int main(){
  ll a = 2, b = 4, c = 42;
  ll xmin = 1, xmax = c, ymin = 1, ymax = c;
  if(a == 0 && b == 0 && c == 0) cout << "x+y = infinity\n";
  else if(a == 0 && b == 0) cout << "No Solution\n";
  else if(a == 0) {
    if(c%b != 0 || ymin > (c/b) || ymax < (c/b)) cout << "No Solution\n";
    else cout << "y is fixed, x can be all in the range\n";
  }
  else if(b == 0) {
    if(c%a != 0 || xmin > (c/a) || xmax < (c/a)) cout << 0 << "\n";
    else cout << "x is fixed, y can be all in the range\n";
  }
  else {
    ll lx, rx;
    ll val = find_all_solutions(a, b, c, xmin, xmax, ymin, ymax, lx, rx);
    if(val == 0) {
      cout << "No Solution\n";
    }
    else {
      ll res = find_maximum(a, b, c, lx, rx);
      cout << res << "\n";
    }
  }

  return 0;
}

/*
2 4 42
4 2 42
2 4 10
*/







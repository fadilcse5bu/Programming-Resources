/// You are given a tree with nodes numbered 1 to n that is rooted at node 1.
/// Type 1: 1 u val, update the value at node u as val
/// Type 2: 2 u, print the sum of squares of values in the subtree (including the node itself) of node u
/// https://www.codechef.com/problems/TREETR

#include <bits/stdc++.h>
using namespace std;
#define ll long long int

int const N = 200005;
ll tree[N], L[N], R[N], ar[N], timer = 0;
vector <ll> edge[N];

// flat tree
void dfs(ll node, ll par) {
  L[node] = ++timer;
  for(ll i = 0; i < edge[node].size(); i++) {
    ll child = edge[node][i];
    if(child != par) {
      dfs(child, node);
    }
  }
  R[node] = timer;
}

// binary index tree
void update(ll id, ll val, ll n) {
  while(id <= n) {
    tree[id] += val;
    id += (id & -id);
  }
}

ll query(ll id) {
  ll sum = 0;
  while(id > 0) {
    sum += tree[id];
    id -= (id & -id);
  }
  return sum;
}

int main()
{
  ll n; cin >> n;
  for(ll i = 1; i <= n; i++) cin >> ar[i];
  for(ll i = 1; i < n; i++) {
    ll u, v; cin >> u >> v;
    edge[u].push_back(v);
    edge[v].push_back(u);
  }
  dfs(1, -1);
  for(ll i = 1; i <= n; i++) {
    ar[i] *= ar[i];
    update(L[i], ar[i], n);
  }
  ll q; cin >> q;
  while(q--) {
    ll tp; cin >> tp;
    if(tp == 1) {
      ll id, val; cin >> id >> val;
      update(L[id], -ar[id], n);
      ar[id] = val*val;
      update(L[id], ar[id], n);
    }
    else {
      ll id; cin >> id;
      ll ans = query(R[id]) - query(L[id]-1);
      cout << ans << endl;
    }
  }

  return 0;
}

/*
9
5 7 5 2 4 1 7 2 3
1 2
2 3
2 4
4 5
4 6
1 7
7 8
7 9
3
2 4
1 4 3
2 4

21
26

*/


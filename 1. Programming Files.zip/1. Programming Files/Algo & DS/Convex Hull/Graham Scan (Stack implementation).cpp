#include <bits/stdc++.h>
using namespace std;
#define ll long long

double PI = acos(-1);
int const N = 1e5+5;

struct Point {
  ll x, y;
};
Point P[N];
vector <Point> cp; //convex point
stack <Point> S;

ll dist(Point p, Point q) {
  return (p.x - q.x)*(p.x - q.x) + (p.y - q.y)*(p.y - q.y);
}

int orientation(Point p, Point q, Point r) {
  ll ret = (p.x*q.y + q.x*r.y + r.x*p.y - q.x*p.y - r.x*q.y - p.x*r.y);
  if(ret < 0) return 2;   // |px qx rx px|
  if(ret > 0) return 1;   // |py qy ry py|
  return ret ;
}

bool cmp(Point X , Point Y) {
  int ret = orientation(P[0], X, Y);
  if(ret==0) {
    ll d1 = dist(P[0],X);
    ll d2 = dist(P[0],Y);
    return d1 < d2 ;
  }
  else if(ret==2) return true ;
  else return false ;
}

Point nextToTop() {
  Point p = S.top();
  S.pop();
  Point res = S.top();
  S.push(p);
  return res;
}

double cal_angle(Point A, Point B, Point C) {
  double a = sqrt((double)dist(A, B));
  double b = sqrt((double)dist(A, C));
  double c = sqrt((double)dist(B, C));
  return acos((a*a + b*b - c*c)/(2.0*a*b));
}

void convexHull(int n) {
  int ymin = P[0].y , index = 0;
  for(int i = 1; i < n; i++) {
    if(P[i].y < ymin || (P[i].y == ymin && P[i].x < P[index].x)) {
      ymin = P[i].y;
      index = i;
    }
  }

  swap(P[0], P[index]);
  sort(&P[1],&P[n],cmp);
  S.push(P[0]);
  for(int i = 1; i < n; i++) {
    while(S.size() > 1 && orientation(nextToTop(), S.top(), P[i]) !=2) {
      S.pop();
    }
    S.push(P[i]);
  }

  while(!S.empty()) {
    cp.push_back(S.top());
    S.pop();
  }
}

int main()
{
  ios_base::sync_with_stdio(false); cin.tie(NULL);
  int t, cs = 1; cin >> t;
  while(t--) {
    int n; cin >> n;
    for(int i = 0; i < n; i++) {
      cin >> P[i].x >> P[i].y;
    }
    cp.clear();
    convexHull(n);
    for(int i = 0; i < cp.size(); i++) cout << cp[i].x << ' ' << cp[i].y << endl;
  }

  return 0;
}


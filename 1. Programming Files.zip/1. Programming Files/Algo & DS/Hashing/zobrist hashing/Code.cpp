/// Zobrist Hashing

#include<bits/stdc++.h>
using namespace std;

int main()
{
  unsigned long long int ar[] = {0, 10, 21, 5, 3, 7};
  int n = 6;
  unsigned long long int HashV = 1615102397; // any random number
  for(int i = 0; i < n; i++) {
    HashV = ((HashV*1615102397) ^ ar[i]);
  }

  cout << HashV << endl; // hash value of the array ar

  // 64 bit hashing
  // collision probability is 2^n

  return 0;
}

// related problem
// https://lightoj.com/problem/olympic-swimming



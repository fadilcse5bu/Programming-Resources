#include <bits/stdc++.h>
using namespace std;
#define ll long long int

ll h[1001], rh[1001], p[1001], base = 29, n, mod = 1e9+7; // mod2 = 1e9+21

int main()
{
  int t = 1, cs = 1;
  cin >> t;
  while(t--) {
    string st, rst;
    cin >> st;
    n = st.size();
    h[0] = 0, rh[n] = 0, p[0] = 1;
    for(int i = 1; i <= n; i++) {
      h[i] = (h[i-1]*base + (st[i-1]-'A'+1))%mod;
      p[i] = (p[i-1]*base)%mod;
    }
    for(int i = n-1; i >= 0; i--) {
      rh[i] = (rh[i+1]*base + (st[i]-'A'+1))%mod;
    }

    for(int i = 1; i <= n; i++) {
      for(int j = i; j <= n; j++) {
        ll v1 = (h[j] - ((h[i-1]*p[j-i+1])%mod) + mod)%mod;
        ll v2 = (rh[i-1] - ((rh[j]*p[j-i+1])%mod) + mod)%mod;
        cout << i << ' ' << j;
        if(v1 == v2) {
          cout << " Palindrom" << endl;
        }
        else cout << " Not Palindrom" << endl;
      }
    }
  }

  return 0;
}




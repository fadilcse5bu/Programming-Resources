#include <bits/stdc++.h>
using namespace std;
#define ll unsigned long long

int n;
double ar[200005], cS[200005];

/// It's impossible to run ternary search if we allow f(i) = f(i+1).
double f(double x) {
  double s = 0.0, mins = 0, maxs = 0;
  for(int i = 1; i <= n; i++){
    s += (ar[i] - x);
    mins = min(mins, s);
    maxs = max(maxs, s);
  }
  return maxs - mins;
}

int main() {
  ios_base::sync_with_stdio(false); cin.tie(NULL);

  cin >> n;
  for(int i = 1; i <= n; i++) cin >> ar[i];

  double lo = -1e9, hi = 1e9, esp = 1e-9;
  int ct = 200;
  while(ct--) {
    double m1 = lo + (hi-lo)/3;
    double m2 = hi - (hi-lo)/3;
    double f1 = f(m1);
    double f2 = f(m2);
    if(f1 > f2) {
      lo = m1;
    }
    else {
      hi = m2;
    }
  }

  cout << fixed << setprecision(10) << f(lo) << endl;

  return 0;
}

/*

3
1 2 3

4
1 2 3 4

10
1 10 2 9 3 8 4 7 5 6

20
-16 -23 29 44 -40 -50 -41 34 -38 30 -12 28 -44 -49 15 50 -28 38 -2 0

*/



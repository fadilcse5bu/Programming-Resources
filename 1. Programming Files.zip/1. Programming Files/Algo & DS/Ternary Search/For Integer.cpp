#include <bits/stdc++.h>
using namespace std;
#define ll unsigned long long

int n;
int ar[200005];

int f(int x) {
  return 0;
}

int main() {
  ios_base::sync_with_stdio(false); cin.tie(NULL);
  cin >> n;
  for(int i = 1; i <= n; i++) cin >> ar[i];
  int lo = 1, hi = n;
  while(lo < hi) {
    int mid = (lo + hi) >> 1;
    if(f(mid) > f(mid+1)) {
      hi = mid;
    }
    else {
      lo = mid+1;
    }
  }

  cout << lo << endl;

  return 0;
}

/*

3
1 2 3

4
1 2 3 4

*/



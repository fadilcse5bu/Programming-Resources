#include <bits/stdc++.h>
using namespace std;
#define ll long long int

/// constraint n,q <= 2*10^5, m <= 20
/// main approach is merge left & right using dp
int const N = 400005; // must take twice of n
long long dp[N][20][20], mod = 1e9+7;
int a[N], n, m, q, len;

void build(int b, int e, int lev){
	if(b == e) return;
	int mid = (b + e)/2;

	for(int j = mid; j >= b; j--) {
    for(int k = 0; k < m; k++) dp[j][lev][k] = 0;
	}
	dp[mid][lev][0] = 1;
	dp[mid][lev][a[mid]%m] += 1;
	for(int j = mid - 1; j >= b; j--) {
    for(int k = 0; k < m; k++) dp[j][lev][k] = dp[j+1][lev][k];
    for(int k = 0; k < m; k++) {
      dp[j][lev][(k+a[j])%m] = (dp[j][lev][(k+a[j])%m] + dp[j+1][lev][k])%mod;
    }
	}

	if(mid + 1 <= e){
    for(int j = mid + 1; j <= e; j++) {
      for(int k = 0; k < m; k++) dp[j][lev][k] = 0;
    }
    dp[mid+1][lev][0] = 1;
    dp[mid+1][lev][a[mid+1]%m] += 1;
    for(int j = mid + 2; j <= e; j++) {
      for(int k = 0; k < m; k++) dp[j][lev][k] = dp[j-1][lev][k];
      for(int k = 0; k < m; k++) {
        dp[j][lev][(k+a[j])%m] = (dp[j][lev][(k+a[j])%m] + dp[j-1][lev][k])%mod;
      }
    }
	}

	build(b, mid, lev+1);
	build(mid+1, e, lev+1);
}

long long query(int l, int r) {
  if(l == r) {
    if(a[l]%m == 0) return 2;
    else return 1;
  }

  ll cnt = 0;
  for(int i = len>>1, j = 0; ; i >>= 1, j++) {
    if(!(i&l)&&(i&r)) {
      for(int k = 0; k < m; k++) {
        cnt = (cnt+(dp[l][j][k]*dp[r][j][(m-k)%m])%mod)%mod;
      }
      break;
    }
  }
  return cnt;
}

int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);

  cin >> n >> m;
  for(int i = 0; i < n; i++) {
    cin >> a[i]; a[i] %= m;
  }

  len = 1;
  while(len < n) len <<= 1;

  build(0, len-1, 0);

  cin >> q;
  while(q--) {
    int l, r; cin >> l >> r;
    cout << query(l-1, r-1) << endl;
  }

	return 0;
}

/*
4 3
5 1 3 2
10
1 1
1 2
1 3
1 4
2 2
2 3
2 4
3 3
3 4
4 4

4 3
5 1 3 2
4
1 2
1 3
1 4
2 4

3 3
3 1 3
6
1 1
1 2
1 3
2 2
2 3
3 3

3 3
3 1 3
1
1 3


*/


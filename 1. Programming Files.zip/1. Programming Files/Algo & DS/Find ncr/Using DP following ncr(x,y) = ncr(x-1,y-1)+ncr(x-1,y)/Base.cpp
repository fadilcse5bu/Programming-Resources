#include<bits/stdc++.h>
using namespace std;
#define ll long long int

int const N = 1005;
ll ncr[N][N], mod = 1e9+7;

/// main idea, ncr(x,y) = ncr(x-1,y-1) + ncr(x-1,y);
void find_ncr() {
  ncr[1][0] = ncr[1][1] = 1;
  for(ll i = 2; i < N; i++) {
    ncr[i][0] = ncr[i][i] = 1;
    for(ll j = 1; j < i; j++) {
      ncr[i][j] = (ncr[i-1][j-1] + ncr[i-1][j])%mod;
    }
  }
}

int main()
{
  find_ncr();
  int t = 1, cs = 1;
  //cin >> t;
  while(t--) {
    cout << ncr[3][2] << endl;
  }

  return 0;
}



/// FFT Equation:
/// (1x^1 + 1x^2 + 1x^3)(1x^2 + 1x^4) = 1x^3 + 1x^4 + 2x^5 + 1x^6 + 1x^7


/// Given an array of size N <= 100000; a[i] < 2^16
/// Find number of triplet (i < j < k) such that a[i] + a[j] = a[k]

#include <bits/stdc++.h>
#define ll long long
using namespace std;

struct cd {
  double x, y;

  cd () : x(0.0), y(0.0) {}
  cd (double _x, double _y) : x(_x), y(_y) {}

  const cd operator + (const cd &z) {
    return cd(x + z.x, y + z.y);
  }

  const cd operator - (const cd &z) {
    return cd(x - z.x, y - z.y);
  }

  const cd operator * (const cd &z) {
    return cd(x * z.x - y * z.y, x * z.y + y * z.x);
  }
};

const int LG = 17;
const int N = 200005;
const int L = 1 << 17;
int rev[N];
const double PI = acos(-1);
cd C[N], A[N], B[N];
cd power[2][20][N];

void process (void) {
  for (int i = 0; i < L; ++i) {
    rev[i] = 0;
    for (int j = 0; j < LG; ++j) {
      if (i & 1 << j) {
        rev[i] |= 1 << (LG - 1 - j);
      }
    }
  }

  for (int dir = 0; dir < 2; ++dir) {
    for (int i = 1; i <= LG; ++i) {
      int l = 1 << i;
      double theta = 2 * PI / l * (dir ? -1 : 1);
      cd base(cos(theta), sin(theta));
      power[dir][i][0] = cd(1, 0);
      for (int j = 1; j < (l >> 1); ++j) {
        power[dir][i][j] = base * power[dir][i][j - 1];
      }
    }
  }
}

void fft (int dir, struct cd *ff) {
  for (int i = 0; i < L; ++i) {
    if (i < rev[i]) {
      swap(ff[i], ff[rev[i]]);
    }
  }

  for (int i = 1; i <= LG; ++i) {
    int l = 1 << i;
    for (int j = 0; j < L; j += l) {
      cd z, *w = power[dir][i];
      cd *u = ff + j, *v = ff + j + (l >> 1);
      cd *lim = ff + j + (l >> 1);
      while (u != lim) {
        z = *v * *w;
        *v = *u - z;
        *u = *u + z;
        ++u, ++v, ++w;
      }
    }
  }

  if (dir == 1) {
    for (int i = 0; i < L; ++i) {
      ff[i].x /= L;
      ff[i].y /= L;
    }
  }
}

int f1[N], f2[N], pf[N], sf[N], cnt[N];

void multiply (void) {
  for (int j = 0; j < L; ++j) {
    A[j] = cd(f1[j], 0);
    B[j] = cd(f2[j], 0);
  }
  fft(0, A);
  fft(0, B);
  for (int j = 0; j < L; ++j) {
    C[j] = A[j] * B[j];
  }
  fft(1, C);
}

int main() {
  process();

  int t; scanf("%d", &t);
  while (t--) {
    memset(pf, 0, sizeof pf);
    memset(sf, 0, sizeof sf);
    memset(f1, 0, sizeof f1);
    memset(f2, 0, sizeof f2);
    memset(cnt, 0, sizeof cnt);

    int n; scanf("%d", &n);
    int ar[n];
    for (int i = 0; i < n; ++i) {
      scanf("%d", ar + i);
      sf[ar[i]]++;
    }

    long long ans = 0;
    const int BS = 2000; /// Bucket Size
    for(int b = 0; b < n; b += BS) {
      for(int i = b; i < b+BS && i < n; i++) {
        for(int j = i+1; j < b+BS && j < n; j++) {
          if(ar[j] > ar[i]) {
            ans += pf[ar[j]-ar[i]];
          }
        }
        pf[ar[i]]++;
        f1[ar[i]]++;
        f2[ar[i]]++;
        sf[ar[i]]--;
      }
      multiply();
      for(int i = 2; i < N; i++) {
        long long add = floor(C[i].x + 0.5);  /// value of C(x) = A(x) * B(x)
        ll cc = add;
        if(i%2 == 0) cc -= pf[i/2];
        cc /= 2;
        ans += ((cc-cnt[i])*sf[i]);
        cnt[i] = cc;
      }
    }

    printf("%lld\n", ans);
  }
  return 0;
}

/*
1
6
2 3 3 4 7 11

output: 3
*/

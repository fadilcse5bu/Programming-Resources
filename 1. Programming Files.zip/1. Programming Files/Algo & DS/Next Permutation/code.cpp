#include <bits/stdc++.h>
using namespace std;
#define ll long long int

bool nextPermutation(vector <int>& nums) {
  int len = nums.size();
  if(len <= 1) return false;
  int i = len - 2;
  while(i >= 0 && nums[i] >= nums[i+1]) --i;
  if(i < 0) return false;
  int l = i+1, r = len - 1;
  while(l < r) {
    int mid = (l+r+1) / 2;
    if(nums[mid] > nums[i]) l = mid;
    else r = mid - 1;
  }
  swap(nums[i], nums[l]);
  reverse(nums.begin()+i+1, nums.end());
  return true;
}

int main()
{
  int t = 1, cs = 1;
  cin >> t;
  while(t--) {
    int n; cin >> n;
    vector <int> v;
    for(int i = 0; i < n; i++) v.push_back(i);
    do {
      for(int i = 0; i < n; i++) cout << v[i] << ' ';
      cout << endl;
    } while(nextPermutation(v));
  }

  return 0;
}

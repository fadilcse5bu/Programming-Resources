#include <bits/stdc++.h>
using namespace std;
#define ll long long int

ll mod = 10007;
int const ln = 4;
ll base[ln][ln] = {{-1,0,-1,1},{1,0,0,0},{0,1,0,0},{0,0,0,1}};

void multiply(ll a[ln][ln], ll b[ln][ln]) {
  ll temp[ln][ln];
  for(int i = 0; i < ln; i++) {
    for(int j = 0; j < ln; j++) {
      temp[i][j] = 0;
      for(int k = 0; k < ln; k++) {
        temp[i][j] += (a[i][k]*b[k][j])%mod;
      }
    }
  }
  for(int i = 0; i < ln; i++) {
    for(int j = 0; j < ln; j++) {
      a[i][j] = temp[i][j];
    }
  }
}

void power(int n, ll mat[ln][ln]) {
  if(n == 1) return;
  power(n/2, mat);
  multiply(mat, mat);
  if(n&1) multiply(mat, base);
}

// f(n) = a*f(n-1) + b*f(n-3) + c
int main()
{
  int t = 1, cs = 1;
  cin >> t;
  while(t--) {
    ll n, a, b, c;
    cin >> n >> a >> b >> c;
    cout << "Case " << cs++ << ": ";
    if(n <= 2) {
      cout << 0 << endl;
      continue;
    }

    base[0][0] = a, base[0][2] = b;
    ll mat[ln][ln] = {{a,0,b,1},{1,0,0,0},{0,1,0,0},{0,0,0,1}};

    power(n-2, mat);
    ll fn = (mat[0][3]*c) % mod;
    cout << fn << endl;
  }

  return 0;
}

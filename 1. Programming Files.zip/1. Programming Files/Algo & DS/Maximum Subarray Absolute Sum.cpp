#include <bits/stdc++.h>
using namespace std;
#define ll unsigned long long


int main() {
  int n; cin >> n;
  int ar[n];
  for(int i = 0; i < n; i++) cin >> ar[i];
  int s = 0, mins = 0, maxs = 0;
  for(int i = 0; i < n; i++){
    s += ar[i];
    mins = min(mins, s);
    maxs = max(maxs, s);
  }
  int ans =  maxs - mins;
  cout << ans << endl;

  return 0;
}

/*
6
-2 -1 2 -3 2 -1

6
-2 -1 4 -3 2 -1
*/




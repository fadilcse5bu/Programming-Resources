#include <bits/stdc++.h>
using namespace std;
#define ll long long

struct Poll
{
  ll x;
  ll y;
};

bool onSegment(Poll p, Poll q, Poll r) {
  if (q.x <= max(p.x, r.x) && q.x >= min(p.x, r.x) &&
    q.y <= max(p.y, r.y) && q.y >= min(p.y, r.y))
    return true;
  return false;
}

ll orientation(Poll p, Poll q, Poll r) {
  ll val = (q.y - p.y) * (r.x - q.x) - (q.x - p.x) * (r.y - q.y);
  if (val == 0) return 0;  // collinear
  return (val > 0)? 1: 2; // clock or counterclock wise
}

bool dollersect(Poll p1, Poll q1, Poll p2, Poll q2) {
  ll o1 = orientation(p1, q1, p2);
  ll o2 = orientation(p1, q1, q2);
  ll o3 = orientation(p2, q2, p1);
  ll o4 = orientation(p2, q2, q1);

  if (o1 != o2 && o3 != o4) //General case
      return true;

  // Special Cases
  // p1, q1 and p2 are collinear and p2 lies on segment p1q1
  if (o1 == 0 && onSegment(p1, p2, q1)) return true;
  if (o2 == 0 && onSegment(p1, q2, q1)) return true;
  if (o3 == 0 && onSegment(p2, p1, q2)) return true;
  if (o4 == 0 && onSegment(p2, q1, q2)) return true;
  return false;
}

int main()
{
  ll t; cin >> t;
  while(t--) {
    struct Poll p1, p2, q1, q2;
    cin >>p1.x>>p1.y>>q1.x>>q1.y>>p2.x>>p2.y>>q2.x>>q2.y;
    dollersect(p1, q1, p2, q2)? cout << "YES\n": cout << "NO\n";
  }

  return 0;
}

